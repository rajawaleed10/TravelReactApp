import * as React from "react";
import { StyleSheet, View, Text, TextInput, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const Login = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.login}>
      <View style={styles.loginChild} />
      <Text style={styles.welcome}>WELCOME !</Text>
      <View style={[styles.email, styles.emailLayout]}>
        <Text style={[styles.email1, styles.email1Typo]}>Email</Text>
        <LinearGradient
          style={styles.wrapper}
          locations={[0, 1]}
          colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
        >
          <TextInput
            style={[styles.textinput, styles.textinputBg]}
            keyboardType="default"
          />
        </LinearGradient>
      </View>
      <View style={[styles.password, styles.emailLayout]}>
        <LinearGradient
          style={styles.wrapper}
          locations={[0, 1]}
          colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
        >
          <TextInput
            style={[styles.textinput, styles.textinputBg]}
            keyboardType="default"
            secureTextEntry={true}
          />
        </LinearGradient>
        <Text style={[styles.email1, styles.email1Typo]}>Password</Text>
      </View>
      <Pressable
        style={[styles.loginButton, styles.loginLayout]}
        onPress={() => navigation.navigate("Main")}
      >
        <LinearGradient
          style={[styles.loginButtonChild, styles.loginLayout]}
          locations={[0, 1]}
          colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
        />
        <Text style={[styles.login1, styles.email1Typo]}>LOGIN</Text>
      </Pressable>
      <Text style={[styles.rememberMe, styles.signup1Typo]}>Remember Me</Text>
      <Text
        style={[styles.dontHaveAn, styles.signupPosition]}
      >{`Don’t Have An Account? `}</Text>
      <Pressable
        style={[styles.signup, styles.signupPosition]}
        onPress={() => navigation.navigate("Signup")}
      >
        <Text style={[styles.signup1, styles.signup1Typo]}>SIGNUP</Text>
      </Pressable>
      <Text style={[styles.forgetPassword, styles.signup1Typo]}>
        Forget Password?
      </Text>
      <View style={[styles.loginItem, styles.loginItemPosition]} />
      <Image
        style={[styles.logoIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/logo.png")}
      />
      <Image
        style={[styles.eyeIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/eye.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  emailLayout: {
    height: 79,
    width: 316,
    left: 29,
    position: "absolute",
  },
  email1Typo: {
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.inriaSansRegular,
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  textinputBg: {
    backgroundColor: "transparent",
    borderRadius: Border.br_3xs,
  },
  loginLayout: {
    width: 148,
    height: 39,
    position: "absolute",
  },
  signup1Typo: {
    fontSize: FontSize.size_mini,
    textAlign: "left",
    color: Color.colorWhite,
  },
  signupPosition: {
    top: 850,
    position: "absolute",
  },
  loginItemPosition: {
    top: 741,
    position: "absolute",
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  loginChild: {
    top: 381,
    borderTopLeftRadius: Border.br_xl,
    borderTopRightRadius: Border.br_xl,
    backgroundColor: Color.colorDarkslateblue,
    width: 430,
    height: 551,
    left: 0,
    position: "absolute",
  },
  welcome: {
    marginLeft: -124,
    top: 465,
    left: "50%",
    fontSize: 50,
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.inriaSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  email1: {
    fontFamily: FontFamily.inriaSansRegular,
    top: 0,
    left: 0,
  },
  textinput: {
    height: "100%",
    width: "100%",
    backgroundColor: "transparent",
    borderRadius: Border.br_3xs,
  },
  wrapper: {
    top: 40,
    height: 39,
    width: 316,
    left: 0,
    position: "absolute",
  },
  email: {
    top: 556,
  },
  password: {
    top: 646,
  },
  loginButtonChild: {
    backgroundColor: "transparent",
    borderRadius: Border.br_3xs,
    top: 0,
    left: 0,
  },
  login1: {
    top: 5,
    left: 39,
    fontFamily: FontFamily.inriaSansRegular,
  },
  loginButton: {
    top: 785,
    left: 29,
  },
  rememberMe: {
    left: 54,
    top: 741,
    position: "absolute",
    fontFamily: FontFamily.inriaSansRegular,
  },
  dontHaveAn: {
    fontSize: FontSize.size_mini,
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.inriaSansRegular,
    left: 29,
  },
  signup1: {
    textDecoration: "underline",
    fontFamily: FontFamily.inriaSansBold,
    fontWeight: "700",
    fontSize: FontSize.size_mini,
  },
  signup: {
    left: 295,
  },
  forgetPassword: {
    left: 232,
    width: 118,
    top: 741,
    position: "absolute",
    fontFamily: FontFamily.inriaSansRegular,
  },
  loginItem: {
    backgroundColor: Color.colorWhite,
    width: 19,
    height: 17,
    left: 29,
  },
  logoIcon: {
    height: "6.91%",
    width: "75.95%",
    top: "20.71%",
    right: "11.95%",
    bottom: "72.38%",
    left: "12.09%",
  },
  eyeIcon: {
    height: "2.15%",
    width: "7.19%",
    top: "74.68%",
    right: "20.49%",
    bottom: "23.18%",
    left: "72.33%",
  },
  login: {
    backgroundColor: Color.colorCornflowerblue,
    flex: 1,
    height: 932,
    overflow: "hidden",
    width: "100%",
  },
});

export default Login;
