import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Pressable, View, Text } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const UserPage = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.userPage}>
      <Image
        style={styles.userPageChild}
        contentFit="cover"
        source={require("../assets/rectangle-6.png")}
      />
      <Pressable
        style={styles.homeIconVector}
        onPress={() => navigation.navigate("Main")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/home-icon.png")}
        />
      </Pressable>
      <Image
        style={[styles.groupIcon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/user-icon.png")}
      />
      <View style={styles.userPageItem} />
      <Pressable
        style={[styles.contactIcon, styles.iconPosition]}
        onPress={() => navigation.navigate("ContactUs")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/contact-icon.png")}
        />
      </Pressable>
      <Image
        style={styles.userPageInner}
        contentFit="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Text style={[styles.username, styles.textFlexBox]}>Username</Text>
      <Text style={[styles.email, styles.textFlexBox]}>Email</Text>
      <Text style={[styles.address, styles.textFlexBox]}>Address</Text>
      <Text style={[styles.phone, styles.textFlexBox]}>Phone</Text>
      <Text style={[styles.ismail2012, styles.textTypo]}>ismail_2012</Text>
      <Text style={[styles.ismail2012gmailcom, styles.textTypo]}>
        ismail2012@gmail.com
      </Text>
      <Text style={[styles.bahriaTownPhase, styles.logoutFlexBox]}>
        Bahria Town Phase 3 St. 3 House 3
      </Text>
      <Text style={[styles.text, styles.textTypo]}>+92 356-6675430</Text>
      <Pressable
        style={[styles.logoutButton, styles.logoutLayout]}
        onPress={() => navigation.navigate("Login")}
      >
        <LinearGradient
          style={[styles.logoutButtonChild, styles.logoutLayout]}
          locations={[0, 1]}
          colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
        />
        <Text style={[styles.logout, styles.logoutFlexBox]}>LOGOUT</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  iconPosition: {
    top: "93.56%",
    width: "8.37%",
    height: "4.4%",
    bottom: "2.04%",
    position: "absolute",
  },
  textFlexBox: {
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  textTypo: {
    fontFamily: FontFamily.inriaSansBold,
    fontWeight: "700",
    fontSize: FontSize.size_6xl,
  },
  logoutFlexBox: {
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  logoutLayout: {
    height: 39,
    width: 148,
    position: "absolute",
  },
  userPageChild: {
    top: 841,
    width: 430,
    height: 91,
    left: 0,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
    maxHeight: "100%",
    maxWidth: "100%",
  },
  homeIconVector: {
    left: "6.74%",
    top: "92.38%",
    right: "80.7%",
    width: "12.56%",
    height: "5.58%",
    bottom: "2.04%",
    position: "absolute",
  },
  groupIcon: {
    right: "45.81%",
    left: "45.81%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  userPageItem: {
    top: 928,
    left: 182,
    borderStyle: "solid",
    borderColor: Color.colorWhite,
    borderTopWidth: 9,
    width: 65,
    height: 9,
    position: "absolute",
  },
  contactIcon: {
    left: "84.88%",
    right: "6.74%",
  },
  userPageInner: {
    top: 99,
    width: 168,
    height: 171,
    left: 29,
    position: "absolute",
  },
  username: {
    top: 300,
    fontFamily: FontFamily.inriaSansLight,
    fontWeight: "300",
    fontSize: FontSize.size_6xl,
    color: Color.colorWhite,
    left: 29,
  },
  email: {
    top: 390,
    fontFamily: FontFamily.inriaSansLight,
    fontWeight: "300",
    fontSize: FontSize.size_6xl,
    color: Color.colorWhite,
    left: 29,
  },
  address: {
    top: 480,
    fontFamily: FontFamily.inriaSansLight,
    fontWeight: "300",
    fontSize: FontSize.size_6xl,
    color: Color.colorWhite,
    left: 29,
  },
  phone: {
    top: 556,
    fontFamily: FontFamily.inriaSansLight,
    fontWeight: "300",
    fontSize: FontSize.size_6xl,
    color: Color.colorWhite,
    left: 29,
  },
  ismail2012: {
    top: 330,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
    left: 29,
  },
  ismail2012gmailcom: {
    top: 420,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
    left: 29,
  },
  bahriaTownPhase: {
    top: 510,
    width: 372,
    fontFamily: FontFamily.inriaSansBold,
    fontWeight: "700",
    fontSize: FontSize.size_6xl,
    left: 29,
  },
  text: {
    top: 586,
    left: 33,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  logoutButtonChild: {
    top: 0,
    borderRadius: Border.br_3xs,
    backgroundColor: "transparent",
    left: 0,
  },
  logout: {
    top: 5,
    left: 31,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.inriaSansRegular,
  },
  logoutButton: {
    top: 683,
    left: 141,
  },
  userPage: {
    backgroundColor: Color.colorCornflowerblue,
    flex: 1,
    height: 932,
    overflow: "hidden",
    width: "100%",
  },
});

export default UserPage;
