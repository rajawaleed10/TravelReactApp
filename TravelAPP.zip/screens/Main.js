import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Pressable, View, Text } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const Main = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.main}>
      <Image
        style={styles.mainChild}
        contentFit="cover"
        source={require("../assets/rectangle-6.png")}
      />
      <Image
        style={[styles.homeIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/home-icon.png")}
      />
      <Pressable
        style={[styles.userIcon, styles.iconPosition]}
        onPress={() => navigation.navigate("UserPage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/user-icon.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.contactIcon, styles.iconPosition]}
        onPress={() => navigation.navigate("ContactUs")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/contact-icon.png")}
        />
      </Pressable>
      <View style={styles.mainItem} />
      <Text style={styles.featuredTripPlaces}>Featured Trip Places</Text>
      <Image
        style={[styles.mainInner, styles.mainInnerLayout]}
        contentFit="cover"
        source={require("../assets/rectangle-7.png")}
      />
      <Text style={[styles.mansehra, styles.mansehraTypo]}>Mansehra</Text>
      <Image
        style={[styles.rectangleIcon, styles.mainInnerLayout]}
        contentFit="cover"
        source={require("../assets/rectangle-10.png")}
      />
      <Text style={[styles.mataltan, styles.mansehraTypo]}>Mataltan</Text>
      <Image
        style={[styles.mainChild1, styles.mainChildLayout]}
        contentFit="cover"
        source={require("../assets/rectangle-8.png")}
      />
      <Image
        style={[styles.mainChild2, styles.mainChildLayout]}
        contentFit="cover"
        source={require("../assets/rectangle-9.png")}
      />
      <Text style={[styles.katoraLake, styles.manshiTopTypo]}>Katora Lake</Text>
      <Text style={[styles.manshiTop, styles.manshiTopTypo]}>Manshi Top</Text>
      <Text style={[styles.rs, styles.rsTypo]}>11,000 RS</Text>
      <Text style={[styles.rs1, styles.rsTypo]}>10,000 RS</Text>
      <Text style={[styles.rs2, styles.rs2Typo]}>18,000 RS</Text>
      <Text style={[styles.rs3, styles.rs2Typo]}>13,000 RS</Text>
      <Text style={[styles.daysTripFood, styles.daysTypo1]}>{`5 days trip
Food Included
5 Star Hotel
Bone Fire
Sight Seeing`}</Text>
      <Text style={[styles.daysTripFood1, styles.daysTypo1]}>{`5 days trip
Food Included
5 Star Hotel
Bone Fire
Sight Seeing`}</Text>
      <Text style={[styles.daysTripFood2, styles.daysTypo]}>{`5 days trip
Food Included
5 Star Hotel
Bone Fire
Sight Seeing`}</Text>
      <Text style={[styles.daysTripFood3, styles.daysTypo]}>{`5 days trip
Food Included
5 Star Hotel
Bone Fire
Sight Seeing`}</Text>
      <Pressable
        style={[styles.bookTrip, styles.bookLayout]}
        onPress={() => navigation.navigate("PaymentInfo")}
      >
        <LinearGradient
          style={[styles.bookTripChild, styles.bookLayout]}
          locations={[0, 1]}
          colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
        />
        <Text style={styles.bookTrip1}>BOOK TRIP</Text>
      </Pressable>
      <Pressable
        style={[styles.bookTrip2, styles.bookLayout]}
        onPress={() => navigation.navigate("PaymentInfo")}
      >
        <LinearGradient
          style={[styles.bookTripChild, styles.bookLayout]}
          locations={[0, 1]}
          colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
        />
        <Text style={styles.bookTrip1}>BOOK TRIP</Text>
      </Pressable>
      <Pressable
        style={[styles.bookTrip4, styles.bookPosition]}
        onPress={() => navigation.navigate("PaymentInfo")}
      >
        <LinearGradient
          style={[styles.bookTripChild, styles.bookLayout]}
          locations={[0, 1]}
          colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
        />
        <Text style={styles.bookTrip1}>BOOK TRIP</Text>
      </Pressable>
      <Pressable
        style={[styles.bookTrip6, styles.bookPosition]}
        onPress={() => navigation.navigate("PaymentInfo")}
      >
        <LinearGradient
          style={[styles.bookTripChild, styles.bookLayout]}
          locations={[0, 1]}
          colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
        />
        <Text style={styles.bookTrip1}>BOOK TRIP</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  iconPosition: {
    height: "4.4%",
    width: "8.37%",
    top: "93.56%",
    bottom: "2.04%",
    position: "absolute",
  },
  mainInnerLayout: {
    height: 124,
    width: 148,
    borderRadius: Border.br_smi,
    top: 155,
    position: "absolute",
  },
  mansehraTypo: {
    top: 282,
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.inriaSansBold,
    fontWeight: "700",
    fontSize: FontSize.size_5xl,
    position: "absolute",
  },
  mainChildLayout: {
    top: 506,
    height: 124,
    width: 148,
    borderRadius: Border.br_smi,
    position: "absolute",
  },
  manshiTopTypo: {
    top: 634,
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.inriaSansBold,
    fontWeight: "700",
    fontSize: FontSize.size_5xl,
    position: "absolute",
  },
  rsTypo: {
    fontSize: FontSize.size_xl,
    top: 764,
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.inriaSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  rs2Typo: {
    top: 416,
    fontSize: FontSize.size_xl,
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.inriaSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  daysTypo1: {
    textAlign: "center",
    top: 314,
    fontFamily: FontFamily.inriaSansRegular,
    fontSize: FontSize.size_mini,
    width: 148,
    color: Color.colorWhite,
    position: "absolute",
  },
  daysTypo: {
    top: 667,
    textAlign: "center",
    fontFamily: FontFamily.inriaSansRegular,
    fontSize: FontSize.size_mini,
    width: 148,
    color: Color.colorWhite,
    position: "absolute",
  },
  bookLayout: {
    height: 32,
    width: 120,
    position: "absolute",
  },
  bookPosition: {
    left: 267,
    height: 32,
    width: 120,
    position: "absolute",
  },
  mainChild: {
    top: 841,
    width: 430,
    height: 91,
    left: 0,
    position: "absolute",
  },
  homeIcon: {
    height: "5.58%",
    width: "12.56%",
    top: "92.38%",
    right: "80.7%",
    left: "6.74%",
    bottom: "2.04%",
    maxWidth: "100%",
    position: "absolute",
  },
  icon: {
    height: "100%",
    maxWidth: "100%",
    width: "100%",
  },
  userIcon: {
    left: "45.81%",
    right: "45.81%",
  },
  contactIcon: {
    left: "84.88%",
    right: "6.74%",
  },
  mainItem: {
    top: 928,
    left: 25,
    borderStyle: "solid",
    borderColor: Color.colorWhite,
    borderTopWidth: 9,
    width: 65,
    height: 9,
    position: "absolute",
  },
  featuredTripPlaces: {
    top: 100,
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.inriaSansBold,
    fontWeight: "700",
    fontSize: FontSize.size_5xl,
    left: 29,
    position: "absolute",
  },
  mainInner: {
    left: 29,
  },
  mansehra: {
    left: 50,
  },
  rectangleIcon: {
    left: 253,
  },
  mataltan: {
    left: 278,
  },
  mainChild1: {
    left: 29,
  },
  mainChild2: {
    left: 253,
  },
  katoraLake: {
    left: 40,
  },
  manshiTop: {
    left: 266,
  },
  rs: {
    left: 286,
  },
  rs1: {
    left: 62,
  },
  rs2: {
    left: 60,
  },
  rs3: {
    left: 284,
  },
  daysTripFood: {
    left: 29,
  },
  daysTripFood1: {
    left: 253,
  },
  daysTripFood2: {
    left: 255,
  },
  daysTripFood3: {
    left: 29,
  },
  bookTripChild: {
    top: 0,
    borderRadius: Border.br_3xs,
    backgroundColor: "transparent",
    left: 0,
  },
  bookTrip1: {
    top: 7,
    left: 24,
    fontFamily: FontFamily.inriaSansRegular,
    fontSize: FontSize.size_mini,
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  bookTrip: {
    left: 43,
    width: 120,
    top: 797,
  },
  bookTrip2: {
    top: 452,
    left: 43,
    width: 120,
  },
  bookTrip4: {
    top: 450,
  },
  bookTrip6: {
    top: 797,
  },
  main: {
    backgroundColor: Color.colorCornflowerblue,
    flex: 1,
    height: 932,
    overflow: "hidden",
    width: "100%",
  },
});

export default Main;
