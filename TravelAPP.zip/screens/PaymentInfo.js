import * as React from "react";
import {
  ImageBackground,
  StyleSheet,
  Pressable,
  View,
  Text,
  TextInput,
} from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { Border, FontFamily, FontSize, Color } from "../GlobalStyles";

const PaymentInfo = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.paymentInfo}>
      <ImageBackground
        style={styles.closeUpOnHandsomeManSmili}
        resizeMode="cover"
        source={require("../assets/closeuponhandsomemansmiling.png")}
      />
      <Image
        style={styles.paymentInfoChild}
        contentFit="cover"
        source={require("../assets/rectangle-6.png")}
      />
      <Pressable
        style={styles.homeIconVector}
        onPress={() => navigation.navigate("Main")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/home-icon.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.group, styles.groupPosition]}
        onPress={() => navigation.navigate("UserPage")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/user-icon.png")}
        />
      </Pressable>
      <View style={styles.paymentInfoItem} />
      <Text style={styles.paymentInformation}>Payment Information</Text>
      <Text style={styles.pleaseAddYour}>
        Please add your credit card to pay
      </Text>
      <Pressable
        style={[styles.contactIcon, styles.groupPosition]}
        onPress={() => navigation.navigate("ContactUs")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/contact-icon.png")}
        />
      </Pressable>
      <LinearGradient
        style={[styles.wrapper, styles.wrapperLayout]}
        locations={[0, 1]}
        colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
      >
        <TextInput
          style={[styles.textinput, styles.textinputBg]}
          keyboardType="decimal-pad"
        />
      </LinearGradient>
      <LinearGradient
        style={[styles.container, styles.wrapperLayout]}
        locations={[0, 1]}
        colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
      >
        <TextInput
          style={[styles.textinput, styles.textinputBg]}
          keyboardType="default"
        />
      </LinearGradient>
      <LinearGradient
        style={[styles.frame, styles.frameLayout]}
        locations={[0, 1]}
        colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
      >
        <TextInput
          style={[styles.textinput, styles.textinputBg]}
          keyboardType="number-pad"
        />
      </LinearGradient>
      <LinearGradient
        style={[styles.rectangleLineargradient, styles.frameLayout]}
        locations={[0, 1]}
        colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
      >
        <TextInput
          style={[styles.textinput, styles.textinputBg]}
          keyboardType="number-pad"
          secureTextEntry={true}
        />
      </LinearGradient>
      <Text style={[styles.cardNumber, styles.payNow1Typo]}>Card Number</Text>
      <Text style={[styles.nameOnThe, styles.payNow1Typo]}>
        Name On The Card
      </Text>
      <Text style={[styles.monthyear, styles.cvcTypo]}>Month/Year</Text>
      <Text style={[styles.cvc, styles.cvcTypo]}>CVC</Text>
      <Image
        style={[styles.visaIcon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/visa-icon.png")}
      />
      <Image
        style={[styles.mastercardIcon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/mastercard-icon.png")}
      />
      <Pressable
        style={[styles.payNow, styles.payLayout]}
        onPress={() => navigation.navigate("PaymentSuccesful")}
      >
        <LinearGradient
          style={[styles.payNowChild, styles.payLayout]}
          locations={[0, 1]}
          colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
        />
        <Text style={[styles.payNow1, styles.payNow1Typo]}>PAY NOW</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  groupPosition: {
    height: "4.4%",
    top: "93.56%",
    width: "8.37%",
    bottom: "2.04%",
    position: "absolute",
  },
  wrapperLayout: {
    height: 32,
    width: 316,
    left: 29,
    position: "absolute",
  },
  textinputBg: {
    backgroundColor: "transparent",
    borderRadius: Border.br_3xs,
  },
  frameLayout: {
    width: 148,
    top: 382,
    height: 32,
    position: "absolute",
  },
  payNow1Typo: {
    fontFamily: FontFamily.inriaSansRegular,
    fontSize: FontSize.size_mini,
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  cvcTypo: {
    top: 354,
    fontFamily: FontFamily.inriaSansRegular,
    fontSize: FontSize.size_mini,
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  iconPosition: {
    bottom: "73.93%",
    top: "24.57%",
    height: "1.5%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  payLayout: {
    width: 120,
    height: 32,
    position: "absolute",
  },
  closeUpOnHandsomeManSmili: {
    left: 83,
    width: 347,
    height: 631,
    top: 301,
    position: "absolute",
  },
  paymentInfoChild: {
    top: 841,
    width: 430,
    height: 91,
    left: 0,
    position: "absolute",
  },
  icon: {
    maxHeight: "100%",
    maxWidth: "100%",
    height: "100%",
    overflow: "hidden",
    width: "100%",
  },
  homeIconVector: {
    left: "6.74%",
    top: "92.38%",
    right: "80.7%",
    width: "12.56%",
    height: "5.58%",
    bottom: "2.04%",
    position: "absolute",
  },
  group: {
    left: "45.81%",
    right: "45.81%",
  },
  paymentInfoItem: {
    top: 928,
    left: 25,
    borderStyle: "solid",
    borderColor: Color.colorWhite,
    borderTopWidth: 9,
    width: 65,
    height: 9,
    position: "absolute",
  },
  paymentInformation: {
    top: 102,
    fontSize: FontSize.size_5xl,
    fontWeight: "700",
    fontFamily: FontFamily.inriaSansBold,
    textAlign: "left",
    color: Color.colorWhite,
    left: 29,
    position: "absolute",
  },
  pleaseAddYour: {
    top: 141,
    fontWeight: "300",
    fontFamily: FontFamily.inriaSansLight,
    fontSize: FontSize.size_mini,
    textAlign: "left",
    color: Color.colorWhite,
    left: 29,
    position: "absolute",
  },
  contactIcon: {
    left: "84.88%",
    right: "6.74%",
  },
  textinput: {
    height: "100%",
    backgroundColor: "transparent",
    borderRadius: Border.br_3xs,
    width: "100%",
  },
  wrapper: {
    top: 220,
  },
  container: {
    top: 301,
  },
  frame: {
    left: 30,
  },
  rectangleLineargradient: {
    left: 197,
  },
  cardNumber: {
    top: 192,
    left: 29,
    fontFamily: FontFamily.inriaSansRegular,
  },
  nameOnThe: {
    top: 273,
    left: 29,
    fontFamily: FontFamily.inriaSansRegular,
  },
  monthyear: {
    left: 30,
  },
  cvc: {
    left: 197,
  },
  visaIcon: {
    right: "28.14%",
    left: "63.49%",
    width: "8.37%",
    bottom: "73.93%",
    top: "24.57%",
    height: "1.5%",
  },
  mastercardIcon: {
    width: "5.35%",
    right: "21.16%",
    left: "73.49%",
  },
  payNowChild: {
    top: 0,
    backgroundColor: "transparent",
    borderRadius: Border.br_3xs,
    left: 0,
  },
  payNow1: {
    top: 7,
    left: 30,
  },
  payNow: {
    top: 447,
    left: 30,
  },
  paymentInfo: {
    backgroundColor: Color.colorCornflowerblue,
    flex: 1,
    height: 932,
    overflow: "hidden",
    width: "100%",
  },
});

export default PaymentInfo;
