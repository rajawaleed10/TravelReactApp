import * as React from "react";
import { StyleSheet, View, Text, TextInput, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const Signup = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.signup}>
      <View style={styles.signupChild} />
      <Text style={styles.letsStartYour}>Let’s Start Your Travel Journey</Text>
      <View style={[styles.name, styles.passwordLayout]}>
        <Text style={[styles.name1, styles.name1Typo]}>Name</Text>
        <LinearGradient
          style={styles.wrapper}
          locations={[0, 1]}
          colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
        >
          <TextInput style={[styles.textinput, styles.textinputBg]} />
        </LinearGradient>
      </View>
      <View style={[styles.email, styles.passwordLayout]}>
        <LinearGradient
          style={styles.wrapper}
          locations={[0, 1]}
          colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
        >
          <TextInput
            style={[styles.textinput, styles.textinputBg]}
            keyboardType="email-address"
          />
        </LinearGradient>
        <Text style={[styles.name1, styles.name1Typo]}>Email</Text>
      </View>
      <View style={[styles.phoneNumber, styles.passwordLayout]}>
        <LinearGradient
          style={styles.wrapper}
          locations={[0, 1]}
          colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
        >
          <TextInput
            style={[styles.textinput, styles.textinputBg]}
            keyboardType="number-pad"
          />
        </LinearGradient>
        <Text style={[styles.name1, styles.name1Typo]}>Phone Number</Text>
      </View>
      <View style={[styles.password, styles.passwordLayout]}>
        <LinearGradient
          style={styles.wrapper}
          locations={[0, 1]}
          colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
        >
          <TextInput
            style={[styles.textinput, styles.textinputBg]}
            secureTextEntry={true}
          />
        </LinearGradient>
        <Text style={[styles.name1, styles.name1Typo]}>Password</Text>
      </View>
      <View style={[styles.retypePassword, styles.passwordLayout]}>
        <LinearGradient
          style={styles.wrapper}
          locations={[0, 1]}
          colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
        >
          <TextInput
            style={[styles.textinput, styles.textinputBg]}
            secureTextEntry={true}
          />
        </LinearGradient>
        <Text style={[styles.name1, styles.name1Typo]}>Re-Type Password</Text>
      </View>
      <Pressable
        style={[styles.loginButton, styles.loginLayout]}
        onPress={() => navigation.navigate("Main")}
      >
        <LinearGradient
          style={[styles.loginButtonChild, styles.loginLayout]}
          locations={[0, 1]}
          colors={["rgba(255, 255, 255, 0.4)", "rgba(255, 255, 255, 0.4)"]}
        />
        <Text style={[styles.login, styles.name1Typo]}>LOGIN</Text>
      </Pressable>
      <Image
        style={styles.logoIcon}
        contentFit="cover"
        source={require("../assets/logo.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  passwordLayout: {
    height: 79,
    width: 316,
    left: 29,
    position: "absolute",
  },
  name1Typo: {
    fontFamily: FontFamily.inriaSansRegular,
    textAlign: "left",
    color: Color.colorWhite,
    fontSize: FontSize.size_5xl,
    position: "absolute",
  },
  textinputBg: {
    backgroundColor: "transparent",
    borderRadius: Border.br_3xs,
  },
  loginLayout: {
    width: 148,
    height: 39,
    position: "absolute",
  },
  signupChild: {
    top: 273,
    borderTopLeftRadius: Border.br_xl,
    borderTopRightRadius: Border.br_xl,
    backgroundColor: Color.colorDarkslateblue,
    width: 433,
    height: 659,
    left: 0,
    position: "absolute",
  },
  letsStartYour: {
    top: 311,
    fontWeight: "700",
    fontFamily: FontFamily.inriaSansBold,
    textAlign: "left",
    color: Color.colorWhite,
    fontSize: FontSize.size_5xl,
    left: 29,
    position: "absolute",
  },
  name1: {
    top: 0,
    left: 0,
  },
  textinput: {
    height: "100%",
    width: "100%",
    backgroundColor: "transparent",
    borderRadius: Border.br_3xs,
  },
  wrapper: {
    top: 40,
    height: 39,
    width: 316,
    left: 0,
    position: "absolute",
  },
  name: {
    top: 369,
  },
  email: {
    top: 459,
  },
  phoneNumber: {
    top: 549,
  },
  password: {
    top: 639,
  },
  retypePassword: {
    top: 729,
  },
  loginButtonChild: {
    backgroundColor: "transparent",
    borderRadius: Border.br_3xs,
    top: 0,
    left: 0,
  },
  login: {
    top: 5,
    left: 39,
  },
  loginButton: {
    top: 833,
    left: 29,
    width: 148,
  },
  logoIcon: {
    height: "6.91%",
    width: "75.95%",
    top: "16.2%",
    right: "11.95%",
    bottom: "76.89%",
    left: "12.09%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  signup: {
    backgroundColor: Color.colorCornflowerblue,
    flex: 1,
    height: 932,
    overflow: "hidden",
    width: "100%",
  },
});

export default Signup;
