/* fonts */
export const FontFamily = {
  inriaSansRegular: "InriaSans-Regular",
  inriaSansBold: "InriaSans-Bold",
  inriaSansLight: "InriaSans-Light",
};
/* font sizes */
export const FontSize = {
  size_mini: 15,
  size_5xl: 24,
  size_xl: 20,
  size_6xl: 25,
};
/* Colors */
export const Color = {
  colorCornflowerblue: "#0071c2",
  colorWhite: "#fff",
  colorDarkslateblue: "#00224f",
};
/* border radiuses */
export const Border = {
  br_3xs: 10,
  br_xl: 20,
  br_smi: 13,
};
