import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Pressable, View, Text } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize } from "../GlobalStyles";

const ContactUs = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.contactUs}>
      <Image
        style={styles.contactUsChild}
        contentFit="cover"
        source={require("../assets/rectangle-6.png")}
      />
      <Image
        style={[styles.homeIconVector, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/home-icon.png")}
      />
      <Pressable
        style={[styles.group, styles.groupPosition]}
        onPress={() => navigation.navigate("UserPage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/user-icon.png")}
        />
      </Pressable>
      <View style={styles.contactUsItem} />
      <Image
        style={[styles.contactIcon, styles.groupPosition]}
        contentFit="cover"
        source={require("../assets/contact-icon.png")}
      />
      <Text style={[styles.youCanContact, styles.aboutUsTypo]}>
        YOU CAN CONTACT US AT
      </Text>
      <Text style={[styles.aboutUs, styles.aboutUsTypo]}>About US</Text>
      <Image
        style={[styles.ticktokIcon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/ticktok-icon.png")}
      />
      <Image
        style={[styles.facebookIcon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/facebook-icon.png")}
      />
      <Image
        style={[styles.instaIcon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/insta-icon.png")}
      />
      <Image
        style={styles.contactUsInner}
        contentFit="cover"
        source={require("../assets/frame-1.png")}
      />
      <Text style={[styles.travelWithTraveller, styles.travellerofficalTypo]}>
        Travel With TRAVELLER
      </Text>
      <Text style={[styles.travelleroffical, styles.travellerofficalTypo]}>
        @traveller.offical
      </Text>
      <Text style={[styles.travelleroffical1, styles.travellerofficalTypo]}>
        @traveller.offical
      </Text>
      <Text style={[styles.travellercontactcom, styles.travellerofficalTypo]}>
        traveller@contact.com
      </Text>
      <Text style={styles.travellerIsMore}>
        TRAVELLER is more than just a travel agency; it's a gateway to
        transformative experiences and lasting memories. Founded in 2003,
        TRAVELLER has carved a niche in crafting exceptional travel itineraries
        for discerning individuals and groups seeking more than a typical
        vacation.
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  groupPosition: {
    height: "4.4%",
    width: "8.37%",
    top: "93.56%",
    bottom: "2.04%",
    position: "absolute",
  },
  aboutUsTypo: {
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.inriaSansBold,
    fontWeight: "700",
    fontSize: FontSize.size_5xl,
    left: 29,
    position: "absolute",
  },
  iconPosition: {
    right: "84.88%",
    width: "8.37%",
    maxHeight: "100%",
    maxWidth: "100%",
    left: "6.74%",
    position: "absolute",
    overflow: "hidden",
  },
  travellerofficalTypo: {
    textAlign: "center",
    left: 85,
    fontSize: FontSize.size_6xl,
    color: Color.colorWhite,
    fontFamily: FontFamily.inriaSansBold,
    fontWeight: "700",
    position: "absolute",
  },
  contactUsChild: {
    top: 841,
    left: 0,
    width: 430,
    height: 91,
    position: "absolute",
  },
  homeIconVector: {
    height: "5.58%",
    width: "12.56%",
    top: "92.38%",
    right: "80.7%",
    left: "6.74%",
    bottom: "2.04%",
    maxWidth: "100%",
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
    maxWidth: "100%",
  },
  group: {
    left: "45.81%",
    right: "45.81%",
  },
  contactUsItem: {
    top: 928,
    left: 351,
    borderStyle: "solid",
    borderColor: Color.colorWhite,
    borderTopWidth: 9,
    width: 65,
    height: 9,
    position: "absolute",
  },
  contactIcon: {
    right: "6.74%",
    left: "84.88%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  youCanContact: {
    top: 102,
  },
  aboutUs: {
    top: 426,
  },
  ticktokIcon: {
    height: "3.33%",
    top: "30.47%",
    bottom: "66.2%",
  },
  facebookIcon: {
    height: "3.43%",
    top: "21.89%",
    bottom: "74.68%",
  },
  instaIcon: {
    height: "3.86%",
    top: "24.25%",
    bottom: "71.89%",
  },
  contactUsInner: {
    top: 337,
    borderRadius: 4,
    width: 36,
    height: 22,
    left: 29,
    position: "absolute",
  },
  travelWithTraveller: {
    top: 173,
  },
  travelleroffical: {
    top: 229,
  },
  travelleroffical1: {
    top: 285,
  },
  travellercontactcom: {
    top: 333,
  },
  travellerIsMore: {
    top: 473,
    fontWeight: "300",
    fontFamily: FontFamily.inriaSansLight,
    width: 372,
    fontSize: FontSize.size_6xl,
    textAlign: "left",
    color: Color.colorWhite,
    left: 29,
    position: "absolute",
  },
  contactUs: {
    backgroundColor: Color.colorCornflowerblue,
    flex: 1,
    height: 932,
    overflow: "hidden",
    width: "100%",
  },
});

export default ContactUs;
